import 'package:flutter/material.dart';
import 'package:flutter_contador/src/app.dart';

//Nosotros escribimos
//import 'src/app.dart';

void main() {
  runApp(MyApp());
}
